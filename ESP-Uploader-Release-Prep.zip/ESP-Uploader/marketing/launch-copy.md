# ESP Uploader — launch campaign draft

## Tagline
**Code it. Compile it. Upload it.**

## Short description
ESP Uploader is a focused coding and firmware-upload workflow for ESP32, ESP32-CAM, ESP8266 and other supported ESP boards. Write Arduino sketches, compile with Arduino CLI, and upload through USB serial. Use the Android companion to control a Windows programming host over Wi-Fi.

## 30-second video ad storyboard
- **0–4 sec:** Close-up of an ESP32-CAM board. On-screen: “Got an ESP board?”
- **4–9 sec:** Show the ESP Uploader code editor. “Write your Arduino code.”
- **9–15 sec:** Tap Compile; show compiler output. “Compile with Arduino CLI.”
- **15–21 sec:** Connect USB-to-serial and tap Upload. “Flash your board.”
- **21–26 sec:** Quick shots: camera, robot car, servo and sensor projects. “Build more with ESP32, ESP32-CAM and ESP8266.”
- **26–30 sec:** Logo and tagline. “ESP Uploader — coming soon.”

## YouTube description
Meet ESP Uploader: a new coding and firmware-upload workflow for ESP32, ESP32-CAM and ESP8266 makers. Write Arduino sketches, compile them with Arduino CLI, and upload firmware through a connected Windows PC. An Android companion can control the Windows host over Wi-Fi.

Development preview. Public downloads and store listings are not live yet.

## Instagram caption
Your ESP board deserves a simple workflow. 💻📷  
Write • Compile • Upload with **ESP Uploader**.  
ESP32 | ESP32-CAM | ESP8266  
Coming soon. Follow for the first release!  
#ESP32 #ESP32CAM #ESP8266 #Arduino #IoT #Robotics #Electronics #ESPUploader

## Launch checklist
- [ ] Finalize app icon and brand assets.
- [ ] Test supported board/core versions and USB adapters.
- [ ] Add crash reporting and privacy policy.
- [ ] Set production API authentication and secure LAN pairing.
- [ ] Build and sign Windows installer.
- [ ] Build and sign Android AAB; complete Play Console declarations.
- [ ] Publish download page with real HTTPS artifact links and checksums.
- [ ] Publish YouTube ad and Instagram Reel only after release dates are confirmed.
- [ ] Never display Google Play badges or “available now” claims before approval.
