import os
import re
import shutil
import subprocess
import tempfile
import threading
import uuid
from pathlib import Path
from typing import Dict, Optional

from fastapi import FastAPI, Header, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from serial.tools import list_ports

APP_TITLE = "ESP Uploader API"
API_TOKEN = os.getenv("ESP_UPLOADER_TOKEN", "dev-only-change-me")
CLI = os.getenv("ARDUINO_CLI", "arduino-cli")
BUILD_ROOT = Path(tempfile.gettempdir()) / "esp-uploader-builds"
BUILD_ROOT.mkdir(parents=True, exist_ok=True)

BOARDS = [
    {"name": "ESP32 Dev Module", "fqbn": "esp32:esp32:esp32"},
    {"name": "AI Thinker ESP32-CAM", "fqbn": "esp32:esp32:esp32cam"},
    {"name": "NodeMCU ESP8266", "fqbn": "esp8266:esp8266:nodemcuv2"},
    {"name": "Wemos D1 mini", "fqbn": "esp8266:esp8266:d1_mini"},
]
BUILDS: Dict[str, dict] = {}

app = FastAPI(title=APP_TITLE, version="0.1.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # LAN companion; protect with API token and trusted network.
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)

class CompileRequest(BaseModel):
    code: str = Field(min_length=1, max_length=200_000)
    fqbn: str
    sketch_name: str = "ESP_Uploader_Sketch"

class UploadRequest(BaseModel):
    build_id: str
    fqbn: str
    port: str

def require_token(x_esp_uploader_token: Optional[str]):
    if not x_esp_uploader_token or x_esp_uploader_token != API_TOKEN:
        raise HTTPException(status_code=401, detail="Invalid or missing ESP Uploader API token.")

def run_cli(args, timeout=600):
    if not shutil.which(CLI) and not Path(CLI).exists():
        raise HTTPException(status_code=503, detail="Arduino CLI was not found. Install it and make sure it is on PATH.")
    try:
        result = subprocess.run(
            [CLI, *args], capture_output=True, text=True, timeout=timeout,
            encoding="utf-8", errors="replace"
        )
    except subprocess.TimeoutExpired:
        raise HTTPException(status_code=504, detail="Arduino CLI operation timed out.")
    return result

@app.get("/api/health")
def health():
    return {"ok": True, "app": APP_TITLE, "version": "0.1.0"}

@app.get("/api/boards")
def boards(x_esp_uploader_token: Optional[str] = Header(default=None)):
    require_token(x_esp_uploader_token)
    return {"boards": BOARDS}

@app.get("/api/ports")
def ports(x_esp_uploader_token: Optional[str] = Header(default=None)):
    require_token(x_esp_uploader_token)
    return {"ports": [
        {"device": p.device, "description": p.description or p.device}
        for p in list_ports.comports()
    ]}

@app.post("/api/compile")
def compile_sketch(req: CompileRequest, x_esp_uploader_token: Optional[str] = Header(default=None)):
    require_token(x_esp_uploader_token)
    if not any(b["fqbn"] == req.fqbn for b in BOARDS):
        raise HTTPException(status_code=400, detail="Unsupported board preset.")
    safe_name = re.sub(r"[^A-Za-z0-9_]", "_", req.sketch_name)[:48] or "ESP_Uploader_Sketch"
    build_id = uuid.uuid4().hex
    sketch_dir = BUILD_ROOT / build_id / safe_name
    out_dir = BUILD_ROOT / build_id / "compiled"
    sketch_dir.mkdir(parents=True, exist_ok=True)
    out_dir.mkdir(parents=True, exist_ok=True)
    (sketch_dir / f"{safe_name}.ino").write_text(req.code, encoding="utf-8")
    result = run_cli(["compile", "--fqbn", req.fqbn, "--output-dir", str(out_dir), str(sketch_dir)])
    output = (result.stdout or "") + ("\n" + result.stderr if result.stderr else "")
    if result.returncode != 0:
        shutil.rmtree(BUILD_ROOT / build_id, ignore_errors=True)
        raise HTTPException(status_code=422, detail=output[-12000:] or "Compilation failed.")
    BUILDS[build_id] = {"sketch_dir": str(sketch_dir), "out_dir": str(out_dir), "fqbn": req.fqbn}
    return {"ok": True, "build_id": build_id, "output": output[-12000:]}

@app.post("/api/upload")
def upload_sketch(req: UploadRequest, x_esp_uploader_token: Optional[str] = Header(default=None)):
    require_token(x_esp_uploader_token)
    build = BUILDS.get(req.build_id)
    if not build:
        raise HTTPException(status_code=404, detail="Build not found. Compile the sketch again.")
    if req.fqbn != build["fqbn"]:
        raise HTTPException(status_code=400, detail="Selected board differs from compiled board.")
    result = run_cli([
        "upload", "--fqbn", req.fqbn, "--port", req.port,
        "--input-dir", build["out_dir"], build["sketch_dir"]
    ], timeout=300)
    output = (result.stdout or "") + ("\n" + result.stderr if result.stderr else "")
    if result.returncode != 0:
        raise HTTPException(status_code=422, detail=output[-12000:] or "Upload failed.")
    return {"ok": True, "output": output[-12000:]}

def start_server():
    import uvicorn
    uvicorn.run(app, host=os.getenv("ESP_UPLOADER_HOST", "0.0.0.0"),
                port=int(os.getenv("ESP_UPLOADER_PORT", "8765")), log_level="warning")

def start_server_thread():
    thread = threading.Thread(target=start_server, daemon=True)
    thread.start()
    return thread
