# ESP Uploader — store listing draft

## Short description
Write, compile and upload Arduino sketches for supported ESP32 and ESP8266 boards.

## Full description
ESP Uploader is a focused tool for makers working with supported ESP development boards.

The Windows desktop app provides a sketch editor, Arduino CLI compilation, USB/serial firmware upload and a serial monitor. Supported presets include ESP32 Dev Module, AI Thinker ESP32-CAM, NodeMCU ESP8266 and Wemos D1 mini.

The Android app is a companion for the Windows programming host. Connect your phone and Windows PC to a trusted local Wi-Fi network, then send compile and upload requests to the PC that is connected to the ESP board over USB/serial.

Use your own Arduino sketches for IoT, robotics, motors, relays, cameras and sensors. Hardware wiring, power requirements, installed board cores and compatible USB drivers remain the user's responsibility.

Important: the Android companion does not currently flash ESP boards directly from the phone. A Windows host is required for compilation and USB/serial uploading.

## Search keywords
ESP32, ESP32-CAM, ESP8266, Arduino, IoT, firmware uploader, serial monitor, NodeMCU, Wemos D1 mini, robotics

## Store assets still required
App icon, phone screenshots, feature graphic, Windows screenshots, privacy policy URL, support email, publisher identity and final signed builds.
