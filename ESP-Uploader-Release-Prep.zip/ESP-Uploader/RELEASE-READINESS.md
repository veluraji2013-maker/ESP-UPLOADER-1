# ESP Uploader — public release readiness

Status: **PRE-RELEASE — not published and not yet verified as a production build.**

## Distribution targets

- Google Play: Android companion app (requires signed AAB, Play Console declarations, testing and review).
- Microsoft Store: Windows desktop app (requires a Windows-built package, Partner Center submission and certification).
- Public website / Google Search: deploy `website/` to a real domain, replace support/contact details, add privacy policy and publish accurate download links. Search indexing is not guaranteed.

## Product limitations that must be disclosed

- The Android app is a Wi-Fi companion to the Windows host. It does not compile or flash an ESP board directly from Android over USB.
- The ESP board is connected to the Windows computer over USB/serial; Android sends requests to the Windows host over the local network.
- Supported board presets are ESP32 Dev Module, AI Thinker ESP32-CAM, NodeMCU ESP8266 and Wemos D1 mini. Other boards need a compatible Arduino CLI core/FQBN.
- Motor, relay, sensor and camera projects are programmed by uploading user sketches; the app does not automatically configure wiring or operate hardware independently.

## Before any public release

1. Build and test on a clean Windows 10/11 machine; install Arduino CLI and required ESP32/ESP8266 cores; test compile and upload on each listed board.
2. Review API security. Do not ship the development default API token; use a strong per-install secret, restrict the service to trusted LAN use, and verify firewall behavior.
3. Add a real publisher/support identity, privacy policy, terms, versioning, app icon, screenshots and store graphics.
4. Build a signed Android App Bundle (AAB) with a production signing key; test on supported Android devices. `compileSdk` and `targetSdk` are set to 36, but dependency/plugin compatibility and policy compliance still need verification.
5. Build and sign the Windows installer/package on Windows. The Inno Setup script is a starting point, not a finished signed installer.
6. Complete store content, age rating, data safety/privacy declarations, pricing and billing configuration; submit separately to Google Play and Microsoft Store.
7. Test the first-10 free offer and ₹10 one-time purchase before advertising it. Do not collect payment outside the relevant store billing rules where they apply.
8. Deploy the website only after real download links, support contact and privacy policy are available.

## Commercial launch plan (proposed, not active)

- First 10 eligible customers: lifetime free unlock.
- Later customers: ₹10 one-time purchase for permanent unlock.
- The first-10 limit must be enforced by a reliable server/store entitlement mechanism and protected against repeated claims. Do not rely on download order or a client-side counter.
- Store billing and promotional-code rules differ by platform. Configure and verify the offer separately in each store before announcing it.

## Build environment

This source bundle does not contain a signed APK/AAB or Windows installer. A Windows build environment is needed for the Windows package, and Android Studio/Android SDK/Gradle are needed for Android. No claim of successful hardware testing or store approval is made by this package.
