package com.espuploader

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.Header
import retrofit2.http.POST

data class CompileBody(val code: String, val fqbn: String, val sketch_name: String = "ESP_Uploader_Sketch")
data class CompileResult(val ok: Boolean, val build_id: String, val output: String)
data class UploadBody(val build_id: String, val fqbn: String, val port: String)
data class UploadResult(val ok: Boolean, val output: String)

interface UploaderApi {
    @POST("api/compile")
    suspend fun compile(@Header("X-ESP-Uploader-Token") token: String, @Body body: CompileBody): CompileResult
    @POST("api/upload")
    suspend fun upload(@Header("X-ESP-Uploader-Token") token: String, @Body body: UploadBody): UploadResult
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ESPUploaderScreen() }
    }
}

@Composable
fun ESPUploaderScreen() {
    var host by remember { mutableStateOf("http://192.168.1.20:8765/") }
    var token by remember { mutableStateOf("dev-only-change-me") }
    var fqbn by remember { mutableStateOf("esp32:esp32:esp32cam") }
    var port by remember { mutableStateOf("COM3") }
    var code by remember { mutableStateOf("void setup() {\n  Serial.begin(115200);\n}\n\nvoid loop() {\n}") }
    var buildId by remember { mutableStateOf("") }
    var output by remember { mutableStateOf("Connect to the Windows ESP Uploader host on the same Wi-Fi network.") }
    val scope = rememberCoroutineScope()

    MaterialTheme {
        Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("📷 ESP Uploader", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary)
            Text("Android companion • Wi-Fi connection to Windows host")
            OutlinedTextField(host, { host = it }, label = { Text("Windows host URL") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(token, { token = it }, label = { Text("API token") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(fqbn, { fqbn = it }, label = { Text("Board FQBN") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(port, { port = it }, label = { Text("Windows serial port (e.g. COM3)") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(code, { code = it }, label = { Text("Arduino sketch") }, modifier = Modifier.fillMaxWidth().height(260.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = {
                    scope.launch {
                        try {
                            val api = Retrofit.Builder().baseUrl(if (host.endsWith("/")) host else "$host/")
                                .addConverterFactory(GsonConverterFactory.create()).build().create(UploaderApi::class.java)
                            val result = api.compile(token, CompileBody(code, fqbn))
                            buildId = result.build_id
                            output = "✓ Compile successful\n${result.output}"
                        } catch (e: Exception) { output = "Compile error: ${e.message}" }
                    }
                }) { Text("Compile") }
                Button(enabled = buildId.isNotBlank(), onClick = {
                    scope.launch {
                        try {
                            val api = Retrofit.Builder().baseUrl(if (host.endsWith("/")) host else "$host/")
                                .addConverterFactory(GsonConverterFactory.create()).build().create(UploaderApi::class.java)
                            val result = api.upload(token, UploadBody(buildId, fqbn, port))
                            output = "✓ Upload successful\n${result.output}"
                        } catch (e: Exception) { output = "Upload error: ${e.message}" }
                    }
                }) { Text("Upload") }
            }
            Text("Output", style = MaterialTheme.typography.titleMedium)
            Text(output)
            Text("Note: The board must be plugged into the Windows PC. The phone controls the Windows uploader over Wi-Fi.")
        }
    }
}
