# ESP Uploader

Cross-platform starter project for programming ESP boards.

- **Windows desktop:** code editor, Arduino CLI compile/upload, serial monitor.
- **Android companion:** connects over Wi-Fi to the Windows programming host and requests compile/upload operations.
- **Website:** product landing page and release-download placeholders.
- **Marketing:** launch copy and campaign checklist.

## Important release status

This repository is a source-code project, not a published product. It does not contain a signed Windows installer or an Android APK yet. The Windows app performs real compilation and upload when Arduino CLI, the correct board core, USB drivers, and a compatible USB-to-UART connection are installed. The Android app is a Wi-Fi companion: the ESP board must be connected to the Windows host by USB. Direct Android-to-board USB flashing is not included in this first version.

## 1. Windows setup

Install Python 3.11 or newer and Arduino CLI.

Install the ESP board cores from PowerShell:

```powershell
arduino-cli core update-index
arduino-cli core install esp32:esp32
arduino-cli core install esp8266:esp8266
```

Install Python packages:

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

Run the desktop application:

```powershell
python desktop/main.py
```

The desktop app starts its local API server automatically. Select the board and serial port, paste or edit an Arduino sketch, then press **Compile** and **Upload**.

### Supported board presets

| Board | Arduino FQBN |
|---|---|
| ESP32 Dev Module | `esp32:esp32:esp32` |
| AI Thinker ESP32-CAM | `esp32:esp32:esp32cam` |
| NodeMCU ESP8266 | `esp8266:esp8266:nodemcuv2` |
| Wemos D1 mini | `esp8266:esp8266:d1_mini` |

Board options vary by core version. Verify the exact FQBN with `arduino-cli board listall` if a board is not recognized.

### ESP32-CAM wiring notes

Many ESP32-CAM boards need a USB-to-TTL adapter. For flashing, connect adapter TX to board U0R, RX to U0T, GND to GND, and hold GPIO0 low during reset/bootloader entry. Use a suitable stable 5V supply. Remove the GPIO0-to-GND connection and reset to run the sketch. Wiring differs by carrier board; check its documentation.

## 2. Android companion setup

Open the `android` folder in Android Studio, allow Gradle sync, and run the app on a phone connected to the same Wi-Fi network as the Windows PC.

In the app, enter the Windows host's LAN address, for example `http://192.168.1.20:8765`, and the API token configured on the Windows host. The Windows firewall may ask permission for the local API.

For LAN use, set a strong token before starting:

```powershell
$env:ESP_UPLOADER_TOKEN="replace-with-a-long-random-secret"
python desktop/main.py
```

Do not expose port 8765 to the public internet. Use a trusted private Wi-Fi network. The initial development default token is not suitable for production.

## 3. Build Windows executable

```powershell
pip install pyinstaller
pyinstaller --noconfirm --clean --onefile --windowed --name "ESP Uploader" desktop/main.py
```

The executable is created in `dist/ESP Uploader.exe`. Keep `arduino-cli.exe` installed and available on PATH, or bundle and configure it for a production build. The Inno Setup script in `installer/` is a starting point for an installer.

## 4. Build Android APK

Open `android/` in Android Studio and build with **Build > Build Bundle(s) / APK(s) > Build APK(s)**. For Google Play, create a signed Android App Bundle (AAB), complete Play Console app-content and data-safety declarations, and submit it for review. The app is not published automatically by this repository.

## 5. Website

Open `website/index.html` locally or deploy the folder to a static host. Replace the placeholder download destinations only after signed builds are produced and hosted. Do not claim Play Store availability until the listing is approved and live.

## Architecture

```text
Android companion --Wi-Fi/HTTP--> Windows ESP Uploader API
                                      |
                                      +--> Arduino CLI compile
                                      |
                                      +--> Arduino CLI upload --> USB serial --> ESP board
```

## Known first-release limitations

- Android is a Wi-Fi remote control for the Windows host, not a standalone compiler/flasher.
- The Windows desktop app includes a 115200-baud serial monitor.
- Third-party libraries must be installed in Arduino CLI before compiling sketches that use them.
- Board support depends on the installed Arduino cores and the board's bootloader/USB interface.
- Motor, relay, camera, and sensor behavior is determined by the sketch and the connected hardware; this app uploads code but does not automatically wire or control hardware.
