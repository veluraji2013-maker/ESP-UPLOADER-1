import os
import sys
import requests
import serial
from PySide6.QtCore import QTimer
from PySide6.QtGui import QFont
from PySide6.QtWidgets import (
    QApplication, QComboBox, QHBoxLayout, QLabel, QMainWindow, QMessageBox,
    QPlainTextEdit, QPushButton, QSplitter, QTextEdit, QVBoxLayout, QWidget
)
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from backend.main import start_server_thread, API_TOKEN

API = "http://127.0.0.1:8765"
DEFAULT_CODE = """// ESP Uploader - starter sketch
void setup() {
  Serial.begin(115200);
  pinMode(2, OUTPUT);
}

void loop() {
  digitalWrite(2, HIGH);
  delay(1000);
  digitalWrite(2, LOW);
  delay(1000);
}
"""

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("ESP Uploader")
        self.resize(1180, 760)
        self.build_id = None
        self.headers = {"X-ESP-Uploader-Token": API_TOKEN}
        self._build_ui()
        self.refresh_ports()

    def _build_ui(self):
        root = QWidget()
        layout = QVBoxLayout(root)
        header = QHBoxLayout()
        brand = QLabel("📷  ESP Uploader")
        brand.setStyleSheet("font-size:24px;font-weight:700;color:#1599ed")
        header.addWidget(brand)
        header.addStretch()
        header.addWidget(QLabel("Board:"))
        self.board = QComboBox()
        self.board.addItem("ESP32 Dev Module", "esp32:esp32:esp32")
        self.board.addItem("AI Thinker ESP32-CAM", "esp32:esp32:esp32cam")
        self.board.addItem("NodeMCU ESP8266", "esp8266:esp8266:nodemcuv2")
        self.board.addItem("Wemos D1 mini", "esp8266:esp8266:d1_mini")
        header.addWidget(self.board)
        header.addWidget(QLabel("Port:"))
        self.port = QComboBox()
        self.port.setMinimumWidth(130)
        header.addWidget(self.port)
        refresh = QPushButton("Refresh")
        refresh.clicked.connect(self.refresh_ports)
        header.addWidget(refresh)
        layout.addLayout(header)

        split = QSplitter()
        self.editor = QPlainTextEdit()
        self.editor.setPlainText(DEFAULT_CODE)
        self.editor.setFont(QFont("Consolas", 11))
        self.editor.setTabStopDistance(32)
        split.addWidget(self.editor)
        right = QWidget()
        right_layout = QVBoxLayout(right)
        right_layout.addWidget(QLabel("Build & Upload"))
        compile_btn = QPushButton("⚙  Compile")
        compile_btn.setStyleSheet("background:#087ee8;color:white;padding:12px;font-weight:700")
        compile_btn.clicked.connect(self.compile_code)
        upload_btn = QPushButton("⬆  Upload")
        upload_btn.setStyleSheet("background:#12a66a;color:white;padding:12px;font-weight:700")
        upload_btn.clicked.connect(self.upload_code)
        right_layout.addWidget(compile_btn)
        right_layout.addWidget(upload_btn)
        right_layout.addWidget(QLabel("Serial Monitor (115200 baud)"))
        self.serial_button = QPushButton("Open Serial Monitor")
        self.serial_button.clicked.connect(self.toggle_serial)
        right_layout.addWidget(self.serial_button)
        self.serial_output = QTextEdit()
        self.serial_output.setReadOnly(True)
        right_layout.addWidget(self.serial_output, 1)
        split.addWidget(right)
        split.setSizes([800, 330])
        layout.addWidget(split, 1)

        self.log = QTextEdit()
        self.log.setReadOnly(True)
        self.log.setMaximumHeight(130)
        self.log.setPlaceholderText("Compile and upload output appears here…")
        layout.addWidget(self.log)
        self.setCentralWidget(root)
        self.setStyleSheet("""
          QMainWindow { background:#f3f7fb; }
          QWidget { font-family:Segoe UI; font-size:10pt; }
          QPlainTextEdit,QTextEdit,QComboBox { background:white;border:1px solid #cbd5e1;border-radius:6px;padding:6px; }
          QPushButton { padding:8px 12px;border:0;border-radius:6px;background:#e2e8f0; }
        """)

        self.serial_timer = QTimer(self)
        self.serial_timer.timeout.connect(self.read_serial)
        self.serial_conn = None

    def request(self, method, path, **kwargs):
        try:
            response = requests.request(method, API + path, headers=self.headers, timeout=600, **kwargs)
            if not response.ok:
                try: message = response.json().get("detail", response.text)
                except Exception: message = response.text
                raise RuntimeError(message)
            return response.json()
        except requests.RequestException as e:
            raise RuntimeError(f"Cannot reach local uploader service: {e}")

    def refresh_ports(self):
        self.port.clear()
        try:
            data = self.request("GET", "/api/ports")
            for p in data["ports"]:
                self.port.addItem(f'{p["device"]} — {p["description"]}', p["device"])
            if not data["ports"]:
                self.port.addItem("No serial ports found", "")
        except Exception as e:
            self.log.setPlainText(str(e))

    def compile_code(self):
        self.log.setPlainText("Compiling…")
        QApplication.processEvents()
        try:
            result = self.request("POST", "/api/compile", json={
                "code": self.editor.toPlainText(),
                "fqbn": self.board.currentData(),
                "sketch_name": "ESP_Uploader_Sketch"
            })
            self.build_id = result["build_id"]
            self.log.setPlainText("✓ Compilation successful\n\n" + result.get("output", ""))
        except Exception as e:
            self.build_id = None
            self.log.setPlainText("✗ Compilation failed\n\n" + str(e))

    def upload_code(self):
        if not self.build_id:
            QMessageBox.information(self, "Compile first", "Compile the current sketch successfully before uploading.")
            return
        port = self.port.currentData()
        if not port:
            QMessageBox.warning(self, "No port", "Connect your board and select its serial port.")
            return
        self.log.setPlainText("Uploading…")
        QApplication.processEvents()
        try:
            result = self.request("POST", "/api/upload", json={
                "build_id": self.build_id, "fqbn": self.board.currentData(), "port": port
            })
            self.log.setPlainText("✓ Upload successful\n\n" + result.get("output", ""))
        except Exception as e:
            self.log.setPlainText("✗ Upload failed\n\n" + str(e))

    def toggle_serial(self):
        if self.serial_conn:
            self.serial_timer.stop()
            self.serial_conn.close()
            self.serial_conn = None
            self.serial_button.setText("Open Serial Monitor")
            return
        port = self.port.currentData()
        if not port:
            QMessageBox.warning(self, "No port", "Connect your board and select its serial port.")
            return
        try:
            self.serial_conn = serial.Serial(port, 115200, timeout=0)
            self.serial_timer.start(100)
            self.serial_button.setText("Close Serial Monitor")
        except Exception as e:
            QMessageBox.critical(self, "Serial connection failed", str(e))

    def read_serial(self):
        if self.serial_conn and self.serial_conn.in_waiting:
            try:
                self.serial_output.moveCursor(self.serial_output.textCursor().End)
                self.serial_output.insertPlainText(self.serial_conn.read(self.serial_conn.in_waiting).decode(errors="replace"))
            except Exception as e:
                self.serial_output.append(str(e))

    def closeEvent(self, event):
        if self.serial_conn:
            self.serial_conn.close()
        event.accept()

if __name__ == "__main__":
    start_server_thread()
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec())
