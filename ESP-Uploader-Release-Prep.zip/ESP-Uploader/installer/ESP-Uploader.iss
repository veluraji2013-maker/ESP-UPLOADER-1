#define MyAppName "ESP Uploader"
#define MyAppVersion "0.1.0"
#define MyAppPublisher "ESP Uploader"
[Setup]
AppId={{5E55C58C-5E71-45A4-9B32-AB2B5A3B2A1C}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={autopf}\ESP Uploader
DefaultGroupName=ESP Uploader
OutputDir=.
OutputBaseFilename=ESP-Uploader-Setup-0.1.0
Compression=lzma
SolidCompression=yes
ArchitecturesInstallIn64BitMode=x64
[Files]
Source: "..\dist\ESP Uploader.exe"; DestDir: "{app}"; Flags: ignoreversion
[Icons]
Name: "{group}\ESP Uploader"; Filename: "{app}\ESP Uploader.exe"
Name: "{autodesktop}\ESP Uploader"; Filename: "{app}\ESP Uploader.exe"
