"""ESP Uploader setup helper for Windows 10/11.

Open this file in Python IDLE and press F5. Run it from the extracted
ESP-Uploader project folder. It creates a virtual environment, installs the
Python dependencies, and creates a launcher batch file.

Arduino CLI and the ESP32/ESP8266 board cores are separate prerequisites.
"""
from pathlib import Path
import os
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
VENV = ROOT / ".venv"
PYTHON = VENV / "Scripts" / "python.exe"
REQUIREMENTS = ROOT / "requirements.txt"
LAUNCHER = ROOT / "Run ESP Uploader.bat"


def run(command, **kwargs):
    print("\n>", " ".join(map(str, command)))
    subprocess.check_call(command, cwd=str(ROOT), **kwargs)


def main():
    if os.name != "nt":
        print("This setup helper is for Windows 10 and Windows 11.")
        input("Press Enter to close...")
        return
    if not REQUIREMENTS.exists() or not (ROOT / "desktop" / "main.py").exists():
        print("Please extract the complete ESP-Uploader folder, then run this script from inside it.")
        input("Press Enter to close...")
        return

    print("ESP Uploader setup — Windows 10/11")
    print("Project folder:", ROOT)
    try:
        if not PYTHON.exists():
            run([sys.executable, "-m", "venv", str(VENV)])
        run([str(PYTHON), "-m", "pip", "install", "--upgrade", "pip"])
        run([str(PYTHON), "-m", "pip", "install", "-r", str(REQUIREMENTS)])
        LAUNCHER.write_text(
            '@echo off\ncd /d "%~dp0"\n"%~dp0.venv\\Scripts\\python.exe" "%~dp0desktop\\main.py"\n'
            'if errorlevel 1 pause\n',
            encoding="utf-8"
        )
        print("\nSetup complete. Double-click 'Run ESP Uploader.bat' to start the app.")
        print("\nIMPORTANT: Uploading firmware also requires Arduino CLI, the correct ESP board core, USB drivers, and a connected board.")
        print("Install Arduino CLI from: https://arduino.github.io/arduino-cli/latest/installation/")
        print("Then run in Command Prompt: arduino-cli core update-index")
        print("For ESP32:   arduino-cli core install esp32:esp32")
        print("For ESP8266: arduino-cli core install esp8266:esp8266")
    except subprocess.CalledProcessError as exc:
        print("\nSetup failed while running:", exc)
        print("Check your internet connection and Python installation, then try again.")
    input("\nPress Enter to close...")


if __name__ == "__main__":
    main()
